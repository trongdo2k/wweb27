# Introduction

Cài đặt packages có sẵn trong `package.json`:

```bash
npm install
```

Cài đặt thêm các packages khác:

```bash
npm install package_name
```

Khởi chạy server dev:

```bash
npm run dev
```

## Deloy lên Vercel

Cài đặt Vercel CLI:

```bash
npm install -g vercel
```

Đăng ký tài khoản [Vercel](https://vercel.com) (Sử dụng Github account)

Deploy

```bash
vercel
```