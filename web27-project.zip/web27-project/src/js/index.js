import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./dropdown.js";
import "../css/index.css";
import "bootstrap/dist/js/bootstrap.min.js";

// document.querySelector("#app").textContent = "Hello World!";

$("#app").html("<h1>Hello World</h1>");
